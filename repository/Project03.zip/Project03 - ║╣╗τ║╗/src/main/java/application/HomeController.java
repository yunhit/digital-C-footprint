package application;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class HomeController {

    @FXML
    private ImageView mainImageView;

    @FXML
    private Button seedButton;

    @FXML
    private ImageView seedIcon;

    @FXML
    private Button worldButton;

    @FXML
    private ImageView worldIcon;

    @FXML
    private Button missionsButton;

    @FXML
    private ImageView missionsIcon;

    @FXML
    private Button reportButton;

    @FXML
    private ImageView reportIcon;

    @FXML
    private void initialize() {
        // 이미지 설정
        mainImageView.setImage(new Image(getClass().getResourceAsStream("/images/HomeScreen.png")));
        worldIcon.setImage(new Image(getClass().getResourceAsStream("/images/world_icon.png")));
        missionsIcon.setImage(new Image(getClass().getResourceAsStream("/images/missions_icon.png")));
        reportIcon.setImage(new Image(getClass().getResourceAsStream("/images/report_icon.png")));
        seedIcon.setImage(new Image(getClass().getResourceAsStream("/images/seed_icon.png")));

        // 버튼 이벤트 설정
        worldButton.setOnAction(e -> {
            // 월드 선택 화면으로 전환
            MainApp.showWorldScreen();
        });

        missionsButton.setOnAction(e -> {
            // 임무 화면으로 전환
            MainApp.showMissionsScreen();
        });

        reportButton.setOnAction(e -> {
            // 탄소 발자국 리포트 화면으로 전환
            MainApp.showReportScreen();
        });
    }
}
